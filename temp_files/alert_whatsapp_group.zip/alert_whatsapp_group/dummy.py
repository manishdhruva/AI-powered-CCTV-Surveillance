from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
import time

def send_whatsapp_group_message(group_name, message):
    options = webdriver.ChromeOptions()
    options.add_argument("--user-data-dir=./User_Data")  # Keeps you logged in
    driver = webdriver.Chrome(options=options)

    # Load WhatsApp Web
    driver.get("https://web.whatsapp.com/")
    print("[🔄] Loading WhatsApp Web...")

    # ✅ Wait until it's fully loaded and logged in
    WebDriverWait(driver, 60).until(
        EC.presence_of_element_located((By.XPATH, '//div[@contenteditable="true"][@data-tab="3"]'))
    )
    print("[✅] WhatsApp Web is ready!")

    try:
        # Search for the group
        search_box = driver.find_element(By.XPATH, '//div[@contenteditable="true"][@data-tab="3"]')
        search_box.click()
        search_box.send_keys(group_name)
        time.sleep(2)
        search_box.send_keys(Keys.ENTER)
        time.sleep(2)

        # Send the message
        message_box = driver.find_element(By.XPATH, '//div[@contenteditable="true"][@data-tab="10"]')
        message_box.click()
        message_box.send_keys(message + Keys.ENTER)
        print(f"[📤] Message sent to group: {group_name}")

    except Exception as e:
        print(f"[❌] Failed: {e}")

    time.sleep(3)
    driver.quit()

# Example usage
group_name = "MetGold Security Team"
message = "*ALERT*: Intrusion detected at Storage Room 2. Please check immediately."
send_whatsapp_group_message(group_name, message)

